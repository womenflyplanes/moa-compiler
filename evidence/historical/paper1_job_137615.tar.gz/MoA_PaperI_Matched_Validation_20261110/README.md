# Paper I matched prediction-versus-validation gate

10 November 2026. Goal: finish the Paper I OpenMP/OpenACC evidence before MPI. The primary question is whether the frozen predicted Ω machine shape is the observed best or within the predeclared penalty. Validate the associated time estimate separately. Different CPU systems require distinct machine records; both original and UA GPU records identify A100 devices. Preserve exact configurations rather than assuming equal time.

## What is complete in this checkpoint

- Recovered original hand-derived sources, corrected ACCESS CPU/GPU CSVs and profiler exports. Eleven source/data files are byte-identical to the nested original software archive; 64 CPU rows, 16 corrected GPU rows and the retained profiler traffic values are independently checked.
- An additive restricted full-output compiler path produces A and O on shaped batched arrays. It saves typed ψ DNF, stable materialized ONF, γ addresses, Ω intervals, generated C and hash-bound certificates. Existing O-only compiler and historical freezes remain unchanged.
- Sixteen host implementation checks pass against an independent materialized reference and the unchanged hand CPU routine. Batch isolation and three semantic rejections pass. Maximum errors: A 1.1102230246251565e-16; O 2.220446049250313e-16. Host fallback is not NVIDIA GPU evidence.
- Three evidence-protocol guards pass: existing run, changed frozen model, and duplicate execution are rejected before a new workload runs.

## Run once on DGX

Copy/extract this package once to DGX, then from its directory on dgx-head01:

```bash
sbatch submit_all.sbatch
```

The job requests one GPU, eight logical CPUs, 32 GB and four hours. It starts immediately on allocation and runs the four distinct realizations: OpenMP CPU, OpenACC multicore CPU, OpenACC A100 and OpenMP target A100. These are new full-output gates, not repetitions of completed online-fold experiments. Scheduling availability and NVHPC support are verified by the actual batch run; no submission or execution is claimed here.

For an already allocated compute shell, a single mode is:

```bash
bash run_matched.sh openacc gpu
```

Each mode prepares new programs, calibrates, freezes, executes held-out cases, validates both outputs, assesses predictions, and archives its evidence. Existing run directories and console logs are protected. The two phases can also be called directly with gate.py; holdout rejects changed frozen inputs. Do not remove markers or rerun completed cases. If a run fails, preserve its archive/log first and diagnose the specific failure.

Python 3 and NumPy are required. NVHPC is required for target GPU and OpenACC multicore performance runs. The wrapper uses the known module and per-job makelocalrc syntax. It rejects GPU fallback. The optional PyTorch full-output baseline runs only if PyTorch is already available; absence remains PENDING, never a successful framework comparison.

## Frozen test contract

B=2, D=64, A shape <B,N,N>, O shape <B,N,D>. Calibration N=96,384,1536; unseen N=64,128,256,512,1024,2048,4096,8192. Seven observations/candidate. CPU Ω candidates <1>,<2>,<4>,<8>; GPU logical candidates <32>,<64>,<128>,<256>. Declare before execution: selection regret <=1.05; selected absolute relative time error <=0.25. Models are fitted on the same implementation/timing boundary used for holdout, then remain frozen. Nonnegative affine work/time fit per candidate is a calibrated model, not a demonstrated architecture-only ten-field predictor.

GPU timing includes transfers and synchronous returned host A,O; input generation, host output allocation and correctness checks are outside the timer. CPU timing uses the analogous generated call. All per-call errors/hashes/timings are retained; large full arrays are not all saved. Inputs reproduce the historical GPU32 or CPU64 generator with explicit integer widths. No batch may consume another batch's keys.

The optional PyTorch callable materializes both outputs using explicit scaled scores, softmax and weighted reduction. It does not benchmark native SDPA. Retain its allocation and timing differences in interpretation. Historical PyTorch SDPA comparisons remain a distinct evidence path until their exact primary records are bound. No speedup is asserted by this package.

## Review and completion

Read ACCESS_PRIMARY_AUDIT.json, local_validation/RESULTS.json, AST_AND_PROGRAMS.md and RESUME_HERE.md. The complete original software archive is retained. Target CPU/GPU predictions, device execution, full size-sweep results, framework comparison and user review remain pending. Do not declare OpenMP/OpenACC or Paper I finished before those obligations are assessed and the paper is updated.
