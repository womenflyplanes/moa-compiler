# Internal scrutiny

- Fixed a substantive contract mismatch: full A and O and independent batch key domains are now explicit in the additional typed lowering. Original source bytes and old predictions remain intact.
- Original CSV/source retrieval is now closed by byte comparison against nested archives, rather than relying on transcribed manuscript numbers. Archive provenance is author-preserved, not an independently authenticated timestamp.
- Local correctness covers 16 finite implementations, including empty-owner and uneven-owner cases, two numerical references and batch isolation. GPU-target builds/runs and NVHPC multicore are not inferred from host fallback.
- New absolute-time model calibrates the actual generated full-output call, eliminating the earlier proxy's timed sin/cos input generation mismatch. This is a proposed remedy, not a validated improvement yet.
- Predicted Ω machine shape is primary. Associated time accuracy is independent. CPU systems differ; both GPU records identify A100. Retain exact environment differences, logical-versus-physical distinction and unknown ten-field values.
- Target paths reject absent GPU execution. Frozen-file changes, existing runs and duplicate execution are rejected. No historical benchmark is rerun during recovery/audit.
- Native SDPA and historical PyTorch measurements are not reconstructed by a new explicit PyTorch full-output baseline. Preserve allocation/residency/timing scope and label pending evidence.
- The full-output A shape uses O(B*N^2) components; do not attribute the online O-only fold's lower storage bound to this realization. Large per-call output arrays are checked but not all retained; hashes/error logs are not saved-array audits.
- The prepared scheduler job has not been submitted or observed by this assistant. Actual NVHPC device compilation/runtime and all new prediction-validation outcomes remain pending. No complete OpenMP/OpenACC verdict is justified yet.
