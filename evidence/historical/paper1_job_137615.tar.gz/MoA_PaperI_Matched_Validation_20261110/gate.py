#!/usr/bin/env python3
"""Prospective full-contract gate: calibrate -> freeze -> holdout. No automatic rerun.
Primary outputs are predicted Ω machine shapes versus observed best shapes.
"""
import argparse,csv,ctypes,datetime,hashlib,json,os,platform,shutil,subprocess,time
from pathlib import Path
import numpy as np
from compiler.moa_full_contract import compile_contract
ROOT=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,x):Path(path).write_text(json.dumps(x,indent=2)+'\n')
def inputs(B,N,D,policy):
    # Explicit widths reproduce the two distinct historical input generators.
    if policy not in ('gpu32','cpu64'):raise ValueError('unknown input policy')
    if ctypes.sizeof(ctypes.c_uint)!=4 or ctypes.sizeof(ctypes.c_ulong)!=8:raise RuntimeError('historical generators require recorded 32-bit unsigned and 64-bit unsigned long')
    arrays=[]
    for seed in (1,2,3):
        x=np.empty(B*N*D,dtype=np.float64);s=seed
        for i in range(x.size):
            if policy=='gpu32':s=(s*1103515245+12345)&0xffffffff;x[i]=(s%20000)/10000.-1.
            else:s=(s*6364136223846793005+1442695040888963407)&0xffffffffffffffff;x[i]=(s&0x7fffffff)/0x7fffffff-1.
        arrays.append(x.reshape(B,N,D))
    return arrays

def oracle(Q,K,V):
    # Independently materialized reference. Batched multiplication keeps key domains separate.
    S=np.matmul(Q,np.swapaxes(K,1,2))/np.sqrt(Q.shape[-1]);S-=np.max(S,axis=-1,keepdims=True)
    np.exp(S,out=S);S/=np.sum(S,axis=-1,keepdims=True)
    return S,np.matmul(S,V)

def build(B,N,D,p,backend,device,folder):
    folder=Path(folder);compile_contract(B,N,D,(p,),backend,folder)
    cc=shutil.which('nvc') if device=='gpu' or backend=='openacc' and shutil.which('nvc') else shutil.which('gcc')
    if not cc:raise RuntimeError('required compiler is absent')
    if Path(cc).name=='nvc':
        flags=['-O3','-fPIC','-shared']
        if backend=='openmp':flags+=['-mp']
        elif backend=='openacc':flags+=['-acc=gpu','-gpu=cc80','-Minfo=accel'] if device=='gpu' else ['-acc=multicore','-Minfo=accel']
        elif backend=='omp_target':flags+=['-mp=gpu','-gpu=cc80','-Minfo=mp']
    else:
        flags=['-O3','-fPIC','-shared','-std=c11']
        if backend in ('openmp','omp_target'):flags+=['-fopenmp']
        if backend=='omp_target':flags+=['-foffload=disable']
        if backend=='openacc':flags+=['-fopenacc']
    cmd=[cc,*flags,str(folder/'generated.c'),'-lm','-o',str(folder/'kernel.so')]
    dump(folder/'build_command.json',cmd)
    z=subprocess.run(cmd,capture_output=True,text=True);(folder/'build.log').write_text(z.stdout+z.stderr)
    if z.returncode:raise RuntimeError('compile failed: '+str(folder/'build.log'))
    return folder/'kernel.so'

def load(path,p,require_gpu):
    lib=ctypes.CDLL(str(Path(path).resolve()))
    if hasattr(lib,'omp_set_dynamic'):lib.omp_set_dynamic(0)
    if hasattr(lib,'omp_set_num_threads'):lib.omp_set_num_threads(p)
    if hasattr(lib,'acc_set_num_cores'):lib.acc_set_num_cores(p)
    lib.moa_device_probe.restype=ctypes.c_int
    actual=lib.moa_device_probe()
    if require_gpu and actual!=1:raise RuntimeError('GPU execution required; fallback rejected')
    lib.moa_run.argtypes=[ctypes.POINTER(ctypes.c_double)]*5
    lib.moa_run.restype=None
    if hasattr(lib,'moa_team_probe'):
        lib.moa_team_probe.restype=ctypes.c_int
        lib.moa_team_count=lib.moa_team_probe()
        if lib.moa_team_count!=p:raise RuntimeError('actual OpenMP team differs from requested candidate')
    return lib,actual

def measure(lib,Q,K,V,reference,repeats):
    B,N,D=Q.shape;A=np.empty((B,N,N));O=np.empty((B,N,D))
    ptr=lambda a:a.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    args=[ptr(a) for a in (Q,K,V,A,O)]
    lib.moa_run(*args) # per-specialization warmup, excluded
    rows=[]
    for r in range(repeats):
        t=time.perf_counter_ns();lib.moa_run(*args);elapsed=(time.perf_counter_ns()-t)/1e6
        errors=[float(np.max(np.abs(x-y))) for x,y in zip((A,O),reference)]
        okay=all(np.all(np.isfinite(x)) and np.allclose(x,y,atol=1e-12,rtol=1e-12) for x,y in zip((A,O),reference))
        if not okay:raise RuntimeError('full (A,O) numerical validation failed')
        rows.append({'repeat':r,'actual_openmp_team':getattr(lib,'moa_team_count',None),'ms':elapsed,'max_abs_A':errors[0],'max_abs_O':errors[1],
          'sha256_A':hashlib.sha256(A.tobytes()).hexdigest(),'sha256_O':hashlib.sha256(O.tobytes()).hexdigest()})
    return rows

def environment():
    d={'host':platform.node(),'platform':platform.platform(),'job':os.getenv('SLURM_JOB_ID'),
       'affinity':sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None,
       'numpy_version':np.__version__,'OMP_NUM_THREADS':os.getenv('OMP_NUM_THREADS'),'CUDA_VISIBLE_DEVICES':os.getenv('CUDA_VISIBLE_DEVICES')}
    for name,cmd in [('cpu',['lscpu']),('gpu',['nvidia-smi','-q']),('compiler',['nvc','--version']),('gcc',['gcc','--version'])]:
        try:z=subprocess.run(cmd,capture_output=True,text=True);d[name]=z.stdout+z.stderr
        except FileNotFoundError:d[name]='unavailable'
    return d

def calibrate(a,run):
    # This is a NEW materialized realization; earlier O-only coefficients are retained separately.
    if a.backend=='openacc' and a.device=='cpu' and not shutil.which('nvc'):raise RuntimeError('CPU performance gate requires nvc multicore; GCC host fallback is correctness-only')
    if a.device=='gpu' and not shutil.which('nvc'):raise RuntimeError('GPU performance gate requires nvc')
    if run.exists():raise RuntimeError('run directory exists; retain it and choose a new run directory')
    if a.device=='cpu' and hasattr(os,'sched_getaffinity') and len(os.sched_getaffinity(0))<8:raise RuntimeError('CPU gate needs eight allocated logical CPUs for the declared candidate set')
    run.mkdir(parents=True);dump(run/'environment.json',environment())
    policy='gpu32' if a.device=='gpu' else 'cpu64'
    plan={'backend':a.backend,'device':a.device,'B':2,'D':64,'input_policy':policy,'outputs':['A','O'],
      'calibration_N':[96,384,1536],'holdout_N':[64,128,256,512,1024,2048,4096,8192],
      'shapes':[[p] for p in ([32,64,128,256] if a.device=='gpu' else [1,2,4,8])],
      'repeats':7,'selection_regret_limit':1.05,'relative_time_error_limit':.25,
      'time_scope':'synchronous complete generated call; host allocation/input generation excluded; GPU H2D/D2H included; returns A and O',
      'machine_properties':['U_d','W_d','M_d','t_d','nmax_d','Mcap_d','P_d','X_d','C_d','R_d'],
      'property_values':'unknown values remain unknown; environment is captured; current model is measured per realization, not a complete physical ten-field predictor',
      'review_status':'user review pending'}
    if a.backend=='openmp' and a.device=='gpu' or a.backend=='omp_target' and a.device!='gpu':raise ValueError('inconsistent backend/device')
    dump(run/'plan.json',plan)
    for N in plan['calibration_N']+plan['holdout_N']:
        for shape in plan['shapes']:build(2,N,64,shape[0],a.backend,a.device,run/f'N{N}_p{shape[0]}')
    raw={};models={};predictions={}
    for N in plan['calibration_N']:
        Q,K,V=inputs(2,N,64,policy);ref=oracle(Q,K,V)
        for shape in plan['shapes']:
            p=shape[0];lib,probe=load(run/f'N{N}_p{p}/kernel.so',p,a.device=='gpu')
            rows=measure(lib,Q,K,V,ref,plan['repeats']);raw[f'{N}:{p}']=rows
            dump(run/'calibration.json',raw)
    for shape in plan['shapes']:
        p=shape[0];x=np.array([2*N*N*64 for N in plan['calibration_N']],dtype=float)
        y=np.array([np.median([r['ms'] for r in raw[f'{N}:{p}']]) for N in plan['calibration_N']])
        candidates=[]
        slope,intercept=np.polyfit(x,y,1)
        if slope>=0 and intercept>=0:candidates.append((float(slope),float(intercept)))
        candidates+=[(0.,float(np.mean(y))),(float(np.dot(x,y)/np.dot(x,x)),0.)]
        slope,intercept=min(candidates,key=lambda t:float(np.sum((y-(t[0]*x+t[1]))**2)))
        models[str(p)]={'slope':slope,'intercept_ms':intercept}
    for N in plan['holdout_N']:
        times={str(s[0]):models[str(s[0])]['slope']*2*N*N*64+models[str(s[0])]['intercept_ms'] for s in plan['shapes']}
        best=min(times,key=lambda p:(times[p],int(p)));predictions[str(N)]={'rho_machine':[int(best)],'predicted_ms':times}
    dump(run/'model.json',models);dump(run/'predictions.json',predictions)
    # Hash all prepared sources, shared objects, calibration records and runner dependencies.
    files={str(f.relative_to(run)):digest(f) for f in run.rglob('*') if f.is_file()}
    dump(run/'freeze.json',{'run_files':files,'runner_sha256':digest(__file__),
      'compiler_sha256':digest(ROOT/'compiler/moa_full_contract.py'),
      'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'holdout_workload_executed':False})
    print('PREDICTIONS FROZEN; HOLDOUT NOT RUN',digest(run/'freeze.json'),flush=True)

def holdout(a,run):
    freeze=json.loads((run/'freeze.json').read_text())
    if digest(__file__)!=freeze['runner_sha256'] or digest(ROOT/'compiler/moa_full_contract.py')!=freeze['compiler_sha256']:raise RuntimeError('frozen compiler/runner changed')
    for n,h in freeze['run_files'].items():
        if digest(run/n)!=h:raise RuntimeError('frozen file changed: '+n)
    plan=json.loads((run/'plan.json').read_text())
    if plan['backend']!=a.backend or plan['device']!=a.device:raise ValueError('holdout backend/device must match frozen plan')
    pred=json.loads((run/'predictions.json').read_text())
    with (run/'EXECUTION_STARTED').open('x') as f:f.write(datetime.datetime.now(datetime.timezone.utc).isoformat())
    rows={};assessment={}
    for N in plan['holdout_N']:
        print('HOLDOUT',N,flush=True);Q,K,V=inputs(2,N,64,plan['input_policy']);ref=oracle(Q,K,V);med={}
        for shape in plan['shapes']:
            p=shape[0];lib,probe=load(run/f'N{N}_p{p}/kernel.so',p,plan['device']=='gpu')
            samples=measure(lib,Q,K,V,ref,plan['repeats']);rows[f'{N}:{p}']={'device_probe':probe,'samples':samples}
            med[str(p)]=float(np.median([r['ms'] for r in samples]));dump(run/'holdout_samples.json',rows)
        selected=str(pred[str(N)]['rho_machine'][0]);best=min(med,key=lambda p:(med[p],int(p)))
        regret=med[selected]/med[best];error=abs(pred[str(N)]['predicted_ms'][selected]/med[selected]-1)
        assessment[str(N)]={'predicted_rho_machine':[int(selected)],'observed_best_rho_machine':[int(best)],
          'exact_shape_match':selected==best,'regret':regret,'shape_selection_pass':regret<=plan['selection_regret_limit'],
          'selected_time_relative_error':error,'time_pass':error<=plan['relative_time_error_limit'],'medians_ms':med}
        dump(run/'assessment.json',assessment)
    dump(run/'COMPLETE.json',{'cases':len(assessment),'selection_pass':sum(v['shape_selection_pass'] for v in assessment.values()),
      'time_pass':sum(v['time_pass'] for v in assessment.values()),'review_status':'user review pending',
      'scope':'finite full (A,O) CPU/GPU gate; no guaranteed prediction law or framework superiority claimed'})
    print((run/'COMPLETE.json').read_text(),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['calibrate','holdout']);ap.add_argument('--backend',choices=['openmp','openacc','omp_target'],required=True);ap.add_argument('--device',choices=['cpu','gpu'],required=True);ap.add_argument('--run',type=Path,required=True)
    a=ap.parse_args();run=a.run.resolve()
    (calibrate if a.phase=='calibrate' else holdout)(a,run)
