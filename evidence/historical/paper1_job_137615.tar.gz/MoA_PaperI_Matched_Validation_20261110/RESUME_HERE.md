# RESUME_HERE — complete the prediction-versus-validation gates

Paper I only. MPI is deferred. User's completion criterion includes mathematics, AST/program chain, frozen machine-shape predictions, numerical/resource/time validation and the hand ACCESS/framework comparisons. New results await user review.

Previous CPU and A100 evidence is preserved; the two-allocation A100 repeatability gate is already complete. Do not repeat it. CPU absolute timing prediction previously failed by 26.8x; first A100 generalization timing passed 4/6, then 6/6 in the second allocation. Keep both records and failures.

NEW completed: original v46 complete archive recovered; eleven hand source/data files match nested original archive bytes. Corrected CPU/GPU/traffic tables checked from raw records. Full (A,O) materialized compiler candidate generated with all four AST stages; 16 finite host implementation checks, batch-isolation and three semantic rejection tests pass; three no-retuning/no-overwrite guards pass. No new GPU or target timing result is claimed.

NEW pending: the full-contract calibration/freeze/holdout protocol on the target CPUs and A100. Run `sbatch submit_all.sbatch` from this package on DGX. This is new work on a different full-output realization; it does not overwrite or retune any historical prediction. Predictions are Ω machine shapes, judged by <=5% selection penalty; associated time error judged separately at <=25%. Return archived results/logs for independent audit and paper integration.

Different CPUs get separate machine records. Both GPU records identify A100s; retain exact configuration metadata. The original hand primary source/CSV retrieval gap is closed. Exact hardware/build configuration transfer and primary historical PyTorch SDPA records remain pending; the optional new PyTorch full-output runner is a distinct baseline. Halide signal-processing history remains separate and preserved.

If PyTorch is absent, generated data remain valid but framework comparison is PENDING. A generated program, a positive host test, and a successful device execution are distinct statuses. A good shape selection does not imply an accurate time estimate or a complete physical ten-field model. Full Paper I and all OpenMP/OpenACC completion criteria are not yet discharged.
