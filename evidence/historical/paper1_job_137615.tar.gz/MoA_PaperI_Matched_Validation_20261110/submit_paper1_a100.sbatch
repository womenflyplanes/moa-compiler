#!/usr/bin/env bash
#SBATCH --partition=dgx
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=04:00:00
#SBATCH --job-name=moa-paper1-a100
#SBATCH --output=moa-paper1-a100-%j.log

set -eo pipefail
cd "$SLURM_SUBMIT_DIR"
source "$HOME/moa-env/setup.sh"
python3 -c 'import sys, numpy; print(sys.executable, numpy.__version__)'
test -f run_matched.sh

python3 - <<'PY'
import ctypes as c

driver = c.CDLL("libcuda.so.1")

def check(status):
    if status:
        raise SystemExit(f"GPU preflight failed with driver status {status}")

check(driver.cuInit(0))
count = c.c_int()
check(driver.cuDeviceGetCount(c.byref(count)))
if count.value != 1:
    raise SystemExit(f"Expected one visible GPU, found {count.value}")
device = c.c_int()
check(driver.cuDeviceGet(c.byref(device), 0))
name = c.create_string_buffer(256)
check(driver.cuDeviceGetName(name, len(name), device))
print("Assigned GPU:", name.value.decode(), flush=True)
if b"A100" not in name.value:
    raise SystemExit("This experiment requires an A100")
PY

bash run_matched.sh openacc gpu
