"""Checks that prediction evidence cannot be silently changed or executed twice."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import hashlib,json
import gate
passed=[]
def put(p,x):p.write_text(json.dumps(x))
with TemporaryDirectory() as d:
 run=Path(d);a=SimpleNamespace(backend='openmp',device='cpu')
 try:gate.calibrate(a,run)
 except RuntimeError as e:assert 'exists' in str(e);passed.append('existing run rejected')
 else:raise AssertionError('overwrite accepted')
 put(run/'plan.json',{'backend':'openmp','device':'cpu'});put(run/'predictions.json',{})
 model=run/'model.json';model.write_text('original')
 freeze={'run_files':{'model.json':gate.digest(model)},'runner_sha256':gate.digest(gate.__file__),'compiler_sha256':gate.digest(gate.ROOT/'compiler/moa_full_contract.py')}
 put(run/'freeze.json',freeze);model.write_text('modified')
 try:gate.holdout(a,run)
 except RuntimeError as e:assert 'changed' in str(e);passed.append('changed frozen model rejected')
 else:raise AssertionError('retune accepted')
 model.write_text('original');(run/'EXECUTION_STARTED').write_text('prior run')
 try:gate.holdout(a,run)
 except FileExistsError:passed.append('second execution rejected before measurement')
 else:raise AssertionError('rerun accepted')
print(json.dumps({'protocol_guards':passed,'hardware_workloads_executed':0}))
(gate.ROOT/'local_validation/PROTOCOL_RESULTS.json').write_text(json.dumps({'pass':passed,'hardware_workloads_executed':0},indent=2)+'\n')
