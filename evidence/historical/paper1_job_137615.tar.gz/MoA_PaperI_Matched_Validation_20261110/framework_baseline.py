#!/usr/bin/env python3
"""Optional NEW PyTorch comparison on the frozen full (A,O) contract.
Does not reconstruct historical PyTorch measurements or select an SDPA backend.
"""
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
from gate import inputs,oracle,digest

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);a=ap.parse_args();run=a.run.resolve()
 if not (run/'COMPLETE.json').exists():raise RuntimeError('complete matched generated holdout first')
 plan=json.loads((run/'plan.json').read_text());freeze=json.loads((run/'freeze.json').read_text())
 for n,h in freeze['run_files'].items():
  if digest(run/n)!=h:raise RuntimeError('frozen evidence changed')
 try:import torch
 except ImportError:raise SystemExit('PyTorch unavailable: framework comparison remains pending; generated run retained')
 gpu=plan['device']=='gpu';device='cuda' if gpu else 'cpu'
 if gpu and not torch.cuda.is_available():raise RuntimeError('GPU framework execution required; no CPU fallback')
 # Set one declared CPU thread count, rather than choosing after timing.
 torch.set_num_threads(max(s[0] for s in plan['shapes']) if not gpu else 1)
 with (run/'FRAMEWORK_STARTED').open('x') as f:f.write('new baseline; no rerun\n')
 results={}
 for N in plan['holdout_N']:
  Q,K,V=inputs(plan['B'],N,plan['D'],plan['input_policy']);ref=oracle(Q,K,V)
  @torch.inference_mode()
  def call():
   q,k,v=[torch.from_numpy(x).to(device) for x in (Q,K,V)]
   scores=(q@k.transpose(-1,-2))/(plan['D']**.5)
   weights=torch.softmax(scores,dim=-1);out=weights@v
   return weights.cpu().numpy(),out.cpu().numpy()
  call();samples=[]
  for r in range(plan['repeats']):
   if gpu:torch.cuda.synchronize()
   start=time.perf_counter_ns();A,O=call()
   if gpu:torch.cuda.synchronize()
   ms=(time.perf_counter_ns()-start)/1e6
   if not all(np.all(np.isfinite(x)) and np.allclose(x,y,atol=1e-12,rtol=1e-12) for x,y in zip((A,O),ref)):raise RuntimeError('framework numerical mismatch')
   samples.append({'ms':ms,'max_A':float(np.max(np.abs(A-ref[0]))),'max_O':float(np.max(np.abs(O-ref[1])))})
  results[str(N)]={'samples':samples,'median_ms':float(np.median([x['ms'] for x in samples]))}
  (run/'framework_samples.json').write_text(json.dumps(results,indent=2)+'\n')
 meta={'torch_version':torch.__version__,'device':device,'gpu_name':torch.cuda.get_device_name() if gpu else None,
  'threads':torch.get_num_threads(),'baseline':'explicit PyTorch scaled score, softmax, weighted reduction; full (A,O); not native SDPA or FlashAttention',
  'timing':'host inputs through returned host A,O, including GPU transfers/synchronization and framework allocation; generated call uses preallocated host outputs; interpretation must retain this allocation difference',
  'historical_pytorch_reproduction':'not established by this new baseline','review_status':'user review pending'}
 (run/'framework_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
 print('Framework records complete; review timing/allocation contract before speedup claims.')
if __name__=='__main__':main()
