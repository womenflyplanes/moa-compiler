#!/usr/bin/env bash
# Use an allocated compute node. This creates a new gate; no previous run is touched.
set -euo pipefail
cd "$(dirname "$0")"
moa_backend=${1:-openacc}
moa_device=${2:-gpu}
if [ -z "${SLURM_JOB_ID:-}" ]; then
  echo 'Run this on an allocated compute node; no Slurm job is visible.' >&2
  exit 2
fi
if [ "$moa_device" = gpu ] || [ "$moa_backend" = openacc ]; then
  if ! command -v nvc >/dev/null; then
    source /etc/profile.d/modules.sh
    module load nvhpc-26.9/nvhpc-nompi/26.9
  fi
  moa_nvc_bin=$(dirname "$(command -v nvc)")
  moa_rc_dir="$PWD/localrc_${SLURM_JOB_ID}_${moa_backend}_${moa_device}"
  if [ ! -e "$moa_rc_dir/localrc" ]; then
    mkdir -p "$moa_rc_dir"
    "$moa_nvc_bin/makelocalrc" "$moa_nvc_bin" -d "$moa_rc_dir" -x -gcc /usr/bin/gcc -gpp /usr/bin/g++
  fi
  export NVLOCALRC="$moa_rc_dir/localrc"
  nvc --version
fi
export OMP_DYNAMIC=FALSE
export OMP_PROC_BIND=close
export OMP_PLACES=cores
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
if [ "$moa_device" = gpu ]; then
  unset ACC_DEVICE_TYPE
  nvidia-smi
  export OMP_TARGET_OFFLOAD=MANDATORY
fi
moa_run="results/job_${SLURM_JOB_ID}_${moa_backend}_${moa_device}"
mkdir -p results
# Refuse rather than overwrite an existing console or run.
if [ -e "$moa_run" ] || [ -e "${moa_run}_console.log" ]; then
  echo "Existing gate retained: $moa_run. Inspect its records; do not rerun it." >&2
  exit 2
fi
exec > >(tee "${moa_run}_console.log") 2>&1
python3 audit_access.py
python3 gate.py calibrate --backend "$moa_backend" --device "$moa_device" --run "$moa_run"
python3 gate.py holdout --backend "$moa_backend" --device "$moa_device" --run "$moa_run"
# Framework absence stays explicitly pending; it does not erase generated records.
if python3 -c 'import torch' >/dev/null 2>&1; then
  python3 framework_baseline.py --run "$moa_run"
else
  printf '%s\n' 'PyTorch unavailable: matched framework baseline PENDING.'
fi
python3 archive_run.py "$moa_run"
