"""New full-interface checks; never represents a rerun of historical experiments."""
import dataclasses,json,os,subprocess,sys
from pathlib import Path
os.environ['ACC_DEVICE_TYPE']='host'
os.environ['OMP_NUM_THREADS']='2'
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from gate import build,load,inputs,oracle,measure
from compiler.moa_full_contract import specification,compile_contract
root=Path(__file__).resolve().parent
out=root/'local_validation';out.mkdir(exist_ok=True)
results=[]
subprocess.run(['gcc','-O3','-std=c11','-fPIC','-shared','-fopenmp',str(root/'hand_reference_wrapper.c'),'-lm','-o',str(out/'hand_reference.so')],check=True)
import ctypes
hand=ctypes.CDLL(str((out/'hand_reference.so').resolve()))
hand.omp_set_num_threads(2)
hand.hand_run.argtypes=[ctypes.POINTER(ctypes.c_double)]*5+[ctypes.c_int]*3
ptr=lambda a:a.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
# Uneven batch/query ownership; more owners than queries; singleton reductions.
for B,N,D,p in [(2,4,8,2),(3,7,5,4),(2,1,1,8),(2,17,3,4)]:
 for backend in ['serial','openmp','openacc','omp_target']:
  folder=out/f'{B}_{N}_{D}_{p}_{backend}'
  path=build(B,N,D,p,backend,'cpu',folder);lib,probe=load(path,min(p,2),False)
  Q,K,V=inputs(B,N,D,'gpu32');ref=oracle(Q,K,V)
  rows=measure(lib,Q,K,V,ref,2)
  hand_A=np.empty((B,N,N));hand_O=np.empty((B,N,D))
  hand.hand_run(*[ptr(x) for x in (Q,K,V,hand_A,hand_O)],B,N,D)
  assert np.allclose(hand_A,ref[0],rtol=1e-12,atol=1e-12) and np.allclose(hand_O,ref[1],rtol=1e-12,atol=1e-12)
  measure(lib,Q,K,V,(hand_A,hand_O),1)
  results.append({'shape':[B,N,D],'rho_machine':[p],'backend':backend,
    'actual_nvidia_device':probe,'pass':True,'max_A':max(r['max_abs_A'] for r in rows),'max_O':max(r['max_abs_O'] for r in rows)})
# Explicit batch isolation: altering batch 1 must leave batch 0 unchanged.
B,N,D,p=2,4,8,2
path=out/'2_4_8_2_openmp/kernel.so';lib,_=load(path,2,False)
Q,K,V=inputs(B,N,D,'gpu32');A=np.empty((B,N,N));O=np.empty_like(Q)
import ctypes
ptr=lambda a:a.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
lib.moa_run(*map(ptr,(Q,K,V,A,O)));before=(A[0].copy(),O[0].copy())
K[1]+=30;V[1]*=-7;lib.moa_run(*map(ptr,(Q,K,V,A,O)))
assert np.array_equal(before[0],A[0]) and np.array_equal(before[1],O[0])
negatives=0
for expr in [dataclasses.replace(specification(),observables=('O',)),dataclasses.replace(specification(),scale='1/D'),dataclasses.replace(specification(),normalization_reduction='b')]:
 try:compile_contract(2,4,8,(2,),'openmp',out/'invalid',expr)
 except ValueError:negatives+=1
 else:raise AssertionError('invalid semantics accepted')
result={'finite_cases':results,'batch_isolation':'PASS','semantic_rejections':negatives,'original_hand_CPU_reference':'PASS on common inputs and both outputs',
 'scope':'new full-contract candidate; host correctness only; OpenACC and OpenMP-target host fallback is not GPU execution; no target timing/prediction validation claimed',
 'review_status':'user review pending'}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'implementations_checked':len(results),'batch_isolation':'PASS','semantic_rejections':negatives,'original_hand_CPU_reference':'PASS on common inputs and both outputs','gpu_validation':'pending'}))
