#!/usr/bin/env bash
#SBATCH --partition=dgx
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=04:00:00
#SBATCH --job-name=moa-paper1-matched
#SBATCH --output=moa-matched-%j.log
set -euo pipefail
cd "$SLURM_SUBMIT_DIR"
# Launch immediately after allocation; no unattended interactive prompt.
bash run_matched.sh openmp cpu
bash run_matched.sh openacc cpu
bash run_matched.sh openacc gpu
bash run_matched.sh omp_target gpu
