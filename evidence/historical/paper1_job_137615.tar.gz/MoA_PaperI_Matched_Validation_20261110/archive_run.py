#!/usr/bin/env python3
import hashlib,json,sys,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent;run=Path(sys.argv[1]).resolve()
if root not in run.parents:raise ValueError('run must be inside package')
if not (run/'COMPLETE.json').exists():raise RuntimeError('do not label an incomplete run complete')
archive=root.parent/(root.name+'_'+run.name+'.tar.gz')
# Capture package source, raw hand evidence, all generated ASTs and results.
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:t.add(root,arcname=root.name,filter=lambda i:None if '/__pycache__/' in i.name or '/local_validation/' in i.name else i)
print(hashlib.sha256(archive.read_bytes()).hexdigest(),archive)
