/* MoA full (A,O) contract: typed ψ → stable materialized ONF → γ → Ω.
   Execution/device status is determined by validation, not source emission. */
#include <math.h>
#include <stddef.h>
#include <openacc.h>


int moa_device_probe(void){int yes=0;
#pragma acc serial copyout(yes)
{yes=acc_on_device(acc_device_nvidia);}
return yes;}
void moa_run(const double *Q,const double *K,const double *V,double *A,double *O){
 const size_t B=2,N=96,D=64;
 const double scale=1.0/sqrt((double)D);
 #pragma acc data copyin(Q[0:12288],K[0:12288],V[0:12288]) copyout(A[0:18432],O[0:12288])
{
#pragma acc parallel loop gang num_gangs(256) vector_length(128)
 for(size_t owner=0;owner<256;owner++){
  size_t begin=B*N*owner/256,end=B*N*(owner+1)/256;
  #pragma acc loop seq
  for(size_t q=begin;q<end;q++){
   size_t b=q/N,i=q%N;
   #pragma acc loop seq
   for(size_t k=0;k<N;k++){
    double score=0.0;
    #pragma acc loop vector reduction(+:score)
    for(size_t j=0;j<D;j++)score+=Q[((b*N+i)*D+j)]*K[((b*N+k)*D+j)];
    A[((b*N+i)*N+k)]=score*scale;
   }
   double maximum=-INFINITY;
   #pragma acc loop vector reduction(max:maximum)
   for(size_t k=0;k<N;k++)maximum=fmax(maximum,A[((b*N+i)*N+k)]);
   double denom=0.0;
   #pragma acc loop vector reduction(+:denom)
   for(size_t k=0;k<N;k++){double e=exp(A[((b*N+i)*N+k)]-maximum);A[((b*N+i)*N+k)]=e;denom+=e;}
   #pragma acc loop vector
   for(size_t k=0;k<N;k++)A[((b*N+i)*N+k)]/=denom;
   #pragma acc loop vector
   for(size_t v=0;v<D;v++){double value=0.0;
    for(size_t k=0;k<N;k++)value+=A[((b*N+i)*N+k)]*V[((b*N+k)*D+v)];
    O[((b*N+i)*D+v)]=value;
   }
  }
 }
 }
}
