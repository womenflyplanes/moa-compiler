# Completion ledger — Paper I, OpenMP and OpenACC

New work is user-review pending. MPI is deferred.

| Obligation | Evidence now available | Remaining requirement |
|---|---|---|
| MoA mathematics and program trace | Original hand source; prior output-only AST chain; new typed ψ/stable ONF/γ/Ω full-output chain | Integrate target execution certificates and predictions with the same observable contract |
| Original ACCESS source/data continuity | Eleven source/data files byte-identical to original nested software archive; CPU/GPU/profiler tables checked | Complete exact build/hardware metadata for qualified cross-system transfer |
| OpenMP CPU prediction/validation | Prior Ω<8> selection validated; absolute-time prediction failed by 26.8x | Execute new full-contract same-kernel calibration/frozen holdout and assess both shape and time targets |
| OpenACC A100 prediction/validation | Prior output-only prospective and two-allocation results audited; first-run timing failures preserved | Validate new full-output realization on A100, with its own frozen predictions |
| OpenACC multicore CPU | New emitted implementation and GCC host checks; not NVHPC multicore execution | Compile/run nvc multicore on allocated CPU resources and assess predicted shapes/time |
| OpenMP target GPU | New emitted implementation and host fallback checks | NVHPC target compilation, positive NVIDIA execution probe, numerical and prediction validation |
| PyTorch comparison | Historical reports preserved; optional new full-(A,O) runner prepared | Execute compatible baseline; retain allocation/timing scope; native historical SDPA reproduction still separate |
| Ten-field physical model | Canonical fields retained; logical counts and Ω coverage derived | Missing physical values and complete capacity/dispatch/time composition remain open |
| Paper | Updated research extension with evidence, AST/program links, derivations and honest failures | Integrate new target outcomes and user review before declaring completion |

The target run's candidate selection is correct if regret is <=1.05; time agreement is separately accepted at <=25% relative error. Declare these before seeing new measurements. Failure is evidence: retain it and, if a revised model is needed, create a new model/version with genuinely new holdout measurements. Never fit to these holdout times and relabel the result prospective.

The historical size sweep is known from the hand-derived campaign. Its new compiler-realization timing observations are held out from the new calibrated model; the model does not read historical CSV times. No broad architecture-only or universal guarantee follows from this protocol.
