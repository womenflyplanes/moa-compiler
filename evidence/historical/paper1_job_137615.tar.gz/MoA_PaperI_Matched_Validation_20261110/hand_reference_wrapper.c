/* Original CPU translation unit is included unchanged. Only its static routine
   is exposed to the new validation harness; this wrapper is not a historical run. */
#define main archived_benchmark_main
#include "evidence/hand_derived/source/forward_bench.c"
#undef main
void hand_run(const double *Q,const double *K,const double *V,double *A,double *O,int B,int N,int D){
 forward_dnf_omp(Q,K,V,A,O,1.0/sqrt((double)D),B,N,D);
}
