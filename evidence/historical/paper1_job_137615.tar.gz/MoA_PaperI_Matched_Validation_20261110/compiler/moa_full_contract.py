"""Restricted typed MoA (A,O) lowering; additive to the archived O-only compiler.
Finite execution checks are distinct from the exact-real normalization identity.
"""
from dataclasses import dataclass,asdict
from math import prod
from pathlib import Path
import hashlib,json

@dataclass(frozen=True)
class Array:
    name:str
    shape:tuple
@dataclass(frozen=True)
class Psi:
    array:Array
    indices:tuple
@dataclass(frozen=True)
class Contract:
    Q:Psi; K:Psi; V:Psi
    score_reduction:str='j'
    normalization_reduction:str='k'
    output_reduction:str='k'
    scale:str='1/sqrt(D)'
    observables:tuple=('A','O')

def specification():
    return Contract(Psi(Array('Q',('B','N','D')),('b','i','j')),
                    Psi(Array('K',('B','N','D')),('b','k','j')),
                    Psi(Array('V',('B','N','D')),('b','k','v')))

def compile_contract(B,N,D,machine_shape,backend,out,expr=None):
    expr=specification() if expr is None else expr
    if expr!=specification():raise ValueError('unsupported complete typed semantics')
    if any(type(x)is not int or x<1 for x in (B,N,D)):raise ValueError('positive integer work shapes')
    if not machine_shape or any(type(x)is not int or x<1 for x in machine_shape):raise ValueError('positive machine shape')
    if backend not in ('serial','openmp','openacc','omp_target'):raise ValueError('unknown backend')
    p=prod(machine_shape);total=B*N
    intervals=[(total*r//p,total*(r+1)//p) for r in range(p)]
    assert [q for lo,hi in intervals for q in range(lo,hi)]==list(range(total))
    addresses={'Q':'((b*N+i)*D+j)','K':'((b*N+k)*D+j)',
               'V':'((b*N+k)*D+v)','A':'((b*N+i)*N+k)','O':'((b*N+i)*D+v)'}
    acc=backend=='openacc';target=backend=='omp_target'
    def directive(kind):
        if acc:
            return {'seq':'#pragma acc loop seq','score':'#pragma acc loop vector reduction(+:score)',
                    'maximum':'#pragma acc loop vector reduction(max:maximum)',
                    'sum':'#pragma acc loop vector reduction(+:denom)',
                    'norm':'#pragma acc loop vector','output':'#pragma acc loop vector'}[kind]
        if target:
            return {'seq':'','score':'#pragma omp parallel for reduction(+:score)',
                    'maximum':'#pragma omp parallel for reduction(max:maximum)',
                    'sum':'#pragma omp parallel for reduction(+:denom)',
                    'norm':'#pragma omp parallel for','output':'#pragma omp parallel for'}[kind]
        return ''
    includes='#include <math.h>\n#include <stddef.h>\n'
    if acc:includes+='#include <openacc.h>\n'
    if backend in ('openmp','omp_target'):includes+='#include <omp.h>\n'
    probe='return 0;'
    if acc:probe='int yes=0;\n#pragma acc serial copyout(yes)\n{yes=acc_on_device(acc_device_nvidia);}\nreturn yes;'
    if target:probe='int yes=0;\n#pragma omp target map(from:yes)\n{yes=!omp_is_initial_device();}\nreturn yes;'
    start=''
    if acc:start=f'#pragma acc data copyin(Q[0:{B*N*D}],K[0:{B*N*D}],V[0:{B*N*D}]) copyout(A[0:{B*N*N}],O[0:{B*N*D}])\n{{\n#pragma acc parallel loop gang num_gangs({p}) vector_length(128)'
    elif target:start=f'#pragma omp target teams distribute num_teams({p}) thread_limit(128) map(to:Q[0:{B*N*D}],K[0:{B*N*D}],V[0:{B*N*D}]) map(from:A[0:{B*N*N}],O[0:{B*N*D}])'
    elif backend=='openmp':start='#pragma omp parallel for schedule(static)'
    team_probe=''
    if backend=='openmp':team_probe='int moa_team_probe(void){int count=1;\n#pragma omp parallel\n{\n#pragma omp single\ncount=omp_get_num_threads();\n}\nreturn count;}\n'
    code=f'''/* MoA full (A,O) contract: typed ψ → stable materialized ONF → γ → Ω.
   Execution/device status is determined by validation, not source emission. */
{includes}
{team_probe}
int moa_device_probe(void){{{probe}}}
void moa_run(const double *Q,const double *K,const double *V,double *A,double *O){{
 const size_t B={B},N={N},D={D};
 const double scale=1.0/sqrt((double)D);
 {start}
 for(size_t owner=0;owner<{p};owner++){{
  size_t begin=B*N*owner/{p},end=B*N*(owner+1)/{p};
  {directive('seq')}
  for(size_t q=begin;q<end;q++){{
   size_t b=q/N,i=q%N;
   {directive('seq')}
   for(size_t k=0;k<N;k++){{
    double score=0.0;
    {directive('score')}
    for(size_t j=0;j<D;j++)score+=Q[{addresses['Q']}]*K[{addresses['K']}];
    A[{addresses['A']}]=score*scale;
   }}
   double maximum=-INFINITY;
   {directive('maximum')}
   for(size_t k=0;k<N;k++)maximum=fmax(maximum,A[{addresses['A']}]);
   double denom=0.0;
   {directive('sum')}
   for(size_t k=0;k<N;k++){{double e=exp(A[{addresses['A']}]-maximum);A[{addresses['A']}]=e;denom+=e;}}
   {directive('norm')}
   for(size_t k=0;k<N;k++)A[{addresses['A']}]/=denom;
   {directive('output')}
   for(size_t v=0;v<D;v++){{double value=0.0;
    for(size_t k=0;k<N;k++)value+=A[{addresses['A']}]*V[{addresses['V']}];
    O[{addresses['O']}]=value;
   }}
  }}
 }}
 { '}' if acc else '' }
}}
'''
    stages={'01_psi_dnf':asdict(expr),'02_stable_materialized_onf':{
      'score':'s[b,i,k] = (1/sqrt(D)) * +red_j (Q[b,i,j] * K[b,k,j])',
      'maximum':'h[b,i] = maxred_k s[b,i,k]',
      'A':'A[b,i,k] = exp(s[b,i,k]-h[b,i]) / +red_l exp(s[b,i,l]-h[b,i])',
      'O':'O[b,i,v] = +red_k (A[b,i,k]*V[b,k,v])',
      'observable':'A and O materialized; A reused first for scores, then exponents, then probabilities',
      'identity_domain':'exact real arithmetic, finite inputs; FP64 established only by finite validation'},
      '03_gamma_onf':addresses,'04_omega':{'rho_machine':list(machine_shape),'query_domain':[B,N],
      'intervals':intervals,'decode':'b=q//N; i=q%N; key reduction stays within batch b',
      'tau_A':B*N*N,'tau_O':B*N*D,'score_multiplications':B*N*N*D,'value_multiplications':B*N*N*D,
      'base_host_array_bytes':8*(4*B*N*D+B*N*N),
      'boundary':'logical counts; not measured DRAM traffic or physical compute-unit assignment'}}
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    for name,val in stages.items():(out/(name+'.json')).write_text(json.dumps(val,indent=2)+'\n')
    (out/'generated.c').write_text(code)
    cert={'backend':backend,'work':[B,N,D],'rho_machine':list(machine_shape),
      'source_sha256':hashlib.sha256(code.encode()).hexdigest(),
      'compiler_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'stage_sha256':{n:hashlib.sha256((out/(n+'.json')).read_bytes()).hexdigest() for n in stages},
      'execution':'pending; source emission does not establish device execution'}
    (out/'certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
    return code
