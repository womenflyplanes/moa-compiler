"""Bind archived hand sources/CSV/profiler records; never executes a historical run."""
from pathlib import Path
import csv,hashlib,io,json,zipfile
ROOT=Path(__file__).resolve().parent
h=ROOT/'evidence'/'hand_derived'
def sha(b):return hashlib.sha256(b).hexdigest()
def audit():
 outer=zipfile.ZipFile(h/'original_software_archive.zip');software=zipfile.ZipFile(io.BytesIO(outer.read('moa_full_software_package.zip')))
 pairs={}
 for f in sorted((h/'source').glob('*')):
  if f.name=='moa_attention.c':key='attention/moa_attention.c'
  else:key='experiments/'+f.name
  assert software.read(key)==f.read_bytes(),f.name
  pairs['source/'+f.name]={'nested_path':key,'sha256':sha(f.read_bytes()),'byte_identical':True}
 for f in sorted((h/'results').glob('*')):
  matches=[n for n in software.namelist() if n.endswith('/'+f.name) and software.read(n)==f.read_bytes()]
  assert matches,f.name
  pairs['results/'+f.name]={'nested_path':matches,'sha256':sha(f.read_bytes()),'byte_identical':True}
 cpu=list(csv.DictReader((h/'results/results_paper1_delta_cpu_21181232.csv').open()))
 scaling={}
 for N in sorted({int(r['N']) for r in cpu}):
  rs=[r for r in cpu if int(r['N'])==N];best=min(rs,key=lambda r:float(r['seconds']));one=next(r for r in rs if int(r['threads'])==1)
  scaling[str(N)]={'best_threads':int(best['threads']),'speedup':float(one['seconds'])/float(best['seconds'])}
 a100=list(csv.DictReader((h/'results/results_paper1_gpu_delta_gpuA100x4_21202354.csv').open()))
 h200=list(csv.DictReader((h/'results/results_paper1_gpu_delta_gpuH200x8_21202355.csv').open()))
 expected=[.242,.383,.788,2.899,8.808,31.952,116.893,457.188]
 assert len(a100)==len(h200)==8
 assert all(abs(float(r['seconds'])*1000-x)<1e-9 for r,x in zip(a100,expected))
 profiler=list(csv.DictReader((h/'results/dram_metrics2.csv').open()))
 measured=profiler[-1]
 assert abs(float(measured['dram__bytes_read.sum'])-9.044992)<1e-9
 assert abs(float(measured['dram__bytes_write.sum'])-142.332928)<1e-9
 dump=list(csv.DictReader((h/'results/full_ncu_dump.csv').open()))
 assert 'sm__warps_active.avg.pct_of_peak_sustained_active' in dump[-1]
 result={'source_and_raw_files':pairs,'cpu_samples':len(cpu),'cpu_scaling_recomputed':scaling,
  'gpu_rows':{'A100':8,'H200':8},'corrected_GPU_table_matches_raw_CSV':True,
  'profiler_last_retained_kernel':{'read_MB':9.044992,'write_MB':142.332928,'total_MB':151.377920},
  'archive_sha256':sha((h/'original_software_archive.zip').read_bytes()),
  'scope':'author-preserved original nested archives; byte identity and aggregate-table consistency verified, not a trusted timestamp or a recovered per-repeat GPU log',
  'machine_note':'CPU systems differ; both GPU records identify A100. Exact ACCESS form factor/capacity/clock/software comparability remains to be documented.',
  'pytorch':'Historical performance claims preserved separately; matching primary PyTorch runner/timing data not present in this hand hardware-results archive.',
  'review_status':'user review pending'}
 (ROOT/'ACCESS_PRIMARY_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS:',len(pairs),'original source/data files byte-identical to nested software archive;',len(cpu),'CPU rows; 16 corrected GPU rows; profiler table matched')
if __name__=='__main__':audit()
