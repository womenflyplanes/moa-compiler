# Traceable MoA mathematics, ASTs and programs

The compiler entry is compiler/moa_full_contract.py: specification() creates a typed Contract with ψ selections on Q,K,V, exact reduction dependencies, D^(-1/2), and observables (A,O). compile_contract() rejects any unsupported semantic expression and derives four records per specialization:

1. 01_psi_dnf.json — typed selectors, shapes, reductions, scaling and observables.
2. 02_stable_materialized_onf.json — scores, row maximum, denominator, normalized A and O selection equations, with the exact-real proof domain.
3. 03_gamma_onf.json — addressed selections for Q,K,V,A,O, preserving b in each key/value access.
4. 04_omega.json — machine shape, complete/disjoint intervals over B*N query ordinals, decode b=q//N and i=q%N, conserved A/O components and logical counts.

The generated.c file realizes these records in serial C, OpenMP CPU, OpenACC, or OpenMP target. certificate.json binds the compiler, stages and source by SHA256. The local_validation subdirectories retain all 16 emitted stage/source/certificate sets plus build commands/logs. Their scope is finite host correctness. Full target-stage/source sets will be produced before calibration/holdout by gate.py.

This candidate is additive and restricted; it does not replace or retroactively describe the prior output-only online-fold AST chain. The saved foundation has that chain in compiler_ast/01_typed_dnf.json through 04_omega_schedule.json; the original A100 audit preserves its corresponding compiler/generated-source certificates. Those are linked separately in the updated paper project.

The original hand programs are preserved byte-for-byte under evidence/hand_derived/source. hand_reference_wrapper.c exposes the archived CPU routine on shared inputs without changing its source. The exact hand GPU program is retained; its historical aggregate means remain separate from the new generated-call measurements. It has not been newly timed on UA by this checkpoint.

The canonical ten machine properties remain U_d,W_d,M_d,t_d,nmax_d,Mcap_d,P_d,X_d,C_d,R_d, in that order. Appending a property must preserve all previous selections. They are property fields, not ten spatial axes. Missing physical values stay unknown. Ω owner counts and nominal memory component counts are not measurements of physical dispatch, DRAM traffic, power or guaranteed time.
